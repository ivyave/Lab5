package th.ac.kku.cis.lab05_api.viewmodel

import androidx.lifecycle.ViewModel

class PokemonDetailViewModel: ViewModel() {
}